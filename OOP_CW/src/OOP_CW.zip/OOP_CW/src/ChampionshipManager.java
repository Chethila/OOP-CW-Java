public interface ChampionshipManager {

}
